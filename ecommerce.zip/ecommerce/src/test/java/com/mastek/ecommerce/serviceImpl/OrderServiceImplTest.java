package com.mastek.ecommerce.serviceImpl;

import org.junit.Test;

import static org.junit.Assert.*;

public class OrderServiceImplTest {

    @Test
    public void finish() {
    }

    @Test
    public void cancel() {
    }
}
