package com.mastek.ecommerce.controller;

import org.junit.Test;


import static org.junit.Assert.*;

public class CartControllerTest {

    @Test
    public void getCart() {
    }
}
