package com.mastek.ecommerce.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mastek.ecommerce.model.ProductInOrder;

public interface ProductInOrderRepository extends JpaRepository<ProductInOrder, Long> {

}
