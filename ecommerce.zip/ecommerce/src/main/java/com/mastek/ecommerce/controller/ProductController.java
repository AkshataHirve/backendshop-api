package com.mastek.ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.mastek.ecommerce.model.ProductInfo;
import com.mastek.ecommerce.service.CategoryService;
import com.mastek.ecommerce.service.ProductService;

import javax.validation.Valid;

@CrossOrigin
@RestController
public class ProductController {
	@Autowired
	CategoryService categoryService;
	@Autowired
	ProductService productService;

	@GetMapping("/product")
	public Page<ProductInfo> findAll(@RequestParam(value = "page", defaultValue = "1") Integer page,
			@RequestParam(value = "size", defaultValue = "6") Integer size) {
		PageRequest request = PageRequest.of(page - 1, size);
		return productService.findAll(request);
	}

	@GetMapping("/product/{productId}")
	public ProductInfo showOne(@PathVariable("productId") String productId) {

		ProductInfo productInfo = productService.findOne(productId);

//        // Product is not available
//        if (productInfo.getProductStatus().equals(ProductStatusEnum.DOWN.getCode())) {
//            productInfo = null;
//        }

		return productInfo;
	}

}
