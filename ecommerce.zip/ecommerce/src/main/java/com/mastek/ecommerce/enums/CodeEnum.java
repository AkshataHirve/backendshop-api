package com.mastek.ecommerce.enums;

public interface CodeEnum {
	Integer getCode();

}
