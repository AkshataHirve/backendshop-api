package com.mastek.ecommerce.service;

import java.util.Collection;

import com.mastek.ecommerce.model.Cart;
import com.mastek.ecommerce.model.ProductInOrder;
import com.mastek.ecommerce.model.User;

public interface CartService {
	Cart getCart(User user);

	void mergeLocalCart(Collection<ProductInOrder> productInOrders, User user);

	void delete(String itemId, User user);

	void checkout(User user);
}
