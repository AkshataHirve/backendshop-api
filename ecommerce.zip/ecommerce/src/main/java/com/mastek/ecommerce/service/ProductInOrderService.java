package com.mastek.ecommerce.service;

import com.mastek.ecommerce.model.ProductInOrder;

import com.mastek.ecommerce.model.User;

public interface ProductInOrderService {
	void update(String itemId, Integer quantity, User user);

	ProductInOrder findOne(String itemId, User user);
}
